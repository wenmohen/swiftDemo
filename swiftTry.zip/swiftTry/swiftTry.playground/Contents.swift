//: Playground - noun: a place where people can play

import UIKit

let myString = "这是第一个swift程序";
let myName = "qewqr";
var age = 22;
age=30;

var bname="hh";
bname="信号";
let score="30分";


let teacher:String="张宏"


let  你好="无线互联"


typealias NSString = String;
let nameds:NSString="hello"


let word="the is width"
let width=23
var mat = word+String(width);
mat += "!"


let str1=12;
let str2=44;
let str3="我有 \(str1) 苹果"
let str4="我有个 \(str2+str1) 栗子"